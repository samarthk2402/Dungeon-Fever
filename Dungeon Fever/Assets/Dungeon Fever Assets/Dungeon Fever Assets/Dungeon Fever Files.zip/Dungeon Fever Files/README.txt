Hey! Thank you so much for choosing my service for this project! It's been a blast and I would be more than happy to continue working with you on future
sprites needed for any project! As agreed all files included in this delivery are intended for commercial use and may be used freely in any current or 
future projects that you work on!

While credit is not required I would greatly appreciate being listed under the name Forest Bailey in the credits of projects that use these assets!

I've done my best to sort all of the sprites into relevant folders, however if anything is missing please do not hesitate to contact me. This project has a large amount
of assets and while I double checked there's always a chance I missed something. Many sprites are sorted into folders based on rarity, or are named based on my intention
for the sprites, however these are all strictly suggestions and I encorage you to change things around if you feel it would work better!

If you have any questions or concerns please feel free to contact me and I'll do my best to help!